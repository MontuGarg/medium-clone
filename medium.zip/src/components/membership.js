import React from 'react'

export default function Membership() {
  return (
    <div id="membership">
        <div id="extradiv"></div>
      <h1>Fuel great thinking.</h1>
      <p>Become a Medium member to enjoy unlimited access and
directly support the writers you read most.<br></br><br></br><br></br><a href='login' className='btn btn-light'>Get unlimited access</a></p>

    </div>
  )
}
